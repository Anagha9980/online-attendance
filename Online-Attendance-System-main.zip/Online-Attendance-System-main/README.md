# Online-Attendance-System
Online Attendance System A web-based application designed to track and manage student or employee attendance in real-time. Built using object-oriented programming principles with features like automated record keeping, report generation, and user-friendly interfaces.
